import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FeatureSilderComponent } from './feature-silder.component';

describe('FeatureSilderComponent', () => {
  let component: FeatureSilderComponent;
  let fixture: ComponentFixture<FeatureSilderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FeatureSilderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FeatureSilderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
