import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-feature-silder',
  templateUrl: './feature-silder.component.html',
  styleUrls: ['./feature-silder.component.scss']
})
export class FeatureSilderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
